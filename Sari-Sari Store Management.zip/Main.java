import managers.SalesManager;
import managers.SalesReportManager;
import models.Payment;
import models.Sales;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Demo of the sales module. */
public class Main {
    public static void main(String[] args) {
        SalesManager sm = new SalesManager();
        SalesReportManager rm = new SalesReportManager(sm);

        Sales sale = sm.startSale("Juan Dela Cruz");
        sm.addItem(sale, "P001", "Notebook", new BigDecimal("45.00"), new BigDecimal("30.00"), 3);
        sm.addItem(sale, "P002", "Ballpen",  new BigDecimal("12.50"), new BigDecimal("7.00"), 4);
        sm.processPayment(sale, Payment.Method.CASH, new BigDecimal("200.00"));
        System.out.println(sm.generateReceipt(sale));

        sm.recordExpense("Electricity bill", "Utilities", new BigDecimal("40.00"), LocalDate.now());

        LocalDate today = LocalDate.now();
        System.out.println(rm.generateReport(today.withDayOfMonth(1), today));
        System.out.println(rm.comparePeriods(today.withDayOfMonth(1), today,
                today.minusMonths(1).withDayOfMonth(1), today.withDayOfMonth(1).minusDays(1)));
    }
}
